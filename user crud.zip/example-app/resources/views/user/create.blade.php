<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-hearder"><h1 class="text-center text-danger">Add a NewUser</h1></div>
                <div class="card-body">
                    <form method="POST" action="{{ route('user.store') }}">
                        @csrf
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Full Name</label>
                            <input type="text" class="form-control"  name="full_name" value="{{ old('full_name') }}" placeholder="Enter your full name ">
                            @error('full_name')
                            <span class="text-danger">{{ $message }}</span>

                            @enderror
                          </div>
                          <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" value="{{ old('email') }}" placeholder="Enter your Email ">
                            @error('email')
                            <span class="text-danger">{{ $message }}</span>

                            @enderror
                          </div>
                          <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" name="phone_number" value="{{ old('phone_number') }}" placeholder="Enter your phone Number ">
                            @error('phone_number')
                            <span class="text-danger">{{ $message }}</span>

                            @enderror
                        </div>
                          <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Enter your password">
                            @error('password')
                            <span class="text-danger">{{ $message }}</span>

                            @enderror
                        </div>
                          <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Confrom_Password</label>
                            <input type="password" class="form-control" name="password_confirmation" placeholder="Enter your Confrom_password">
                            @error('password_confirmation')
                            <span class="text-danger">{{ $message }}</span>

                            @enderror
                        </div>
                        <button class="btn btn-primary" type="submit">Save</button>
                    </form>
                </div>
            </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
