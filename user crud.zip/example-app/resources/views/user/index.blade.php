<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header">
                <h1 class="text-center text-danger">USER DATA SHOW</h1>
                <a href="{{ route('user.create') }}" class="btn btn-success btn-sm float-end">Add User</a>
            </div>
            <div class="card-body">
                <table class="table table-sm table-striped table-bordered">
                <thead class="text-primary">
                    <th>S/N</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Registration Date</th>
                    <th>Last Update</th>
                    <th colspan="2">Action</th>

                </thead>
                <tbody>
                    @foreach ($users as  $item )
                    <tr>
                    <td>{{$item-> id }}</td>
                    <td>{{$item-> name }}</td>
                    <td>{{$item-> email }}</td>
                    <td>{{$item->phone_number }}</td>
                    <td>{{$item-> created_at }}</td>
                    <td>{{$item-> updated_at }}</td>
                    <td><a href="route('user.edit,{{ $item->id }}')" class="btn btn-sm btn-success">Edit</a></td>
                    <td><a href="route('user.delete,{{ $item->id }}')" class="btn btn-sm btn-danger">Delete</a></td>

                    </tr>
                    @endforeach
                </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
