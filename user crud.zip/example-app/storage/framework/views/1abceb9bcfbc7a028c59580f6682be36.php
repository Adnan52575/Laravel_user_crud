<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <div class="card mt-5">
            <div class="card-header">
                <h1 class="text-center text-danger">USER DATA SHOW</h1>
                <a href="<?php echo e(route('user.create')); ?>" class="btn btn-success btn-sm float-end">Add User</a>
            </div>
            <div class="card-body">
                <table class="table table-sm table-striped table-bordered">
                <thead class="text-primary">
                    <th>S/N</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Registration Date</th>
                    <th>Last Update</th>
                    <th colspan="2">Action</th>

                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($item-> id); ?></td>
                    <td><?php echo e($item-> name); ?></td>
                    <td><?php echo e($item-> email); ?></td>
                    <td><?php echo e($item->phone_number); ?></td>
                    <td><?php echo e($item-> created_at); ?></td>
                    <td><?php echo e($item-> updated_at); ?></td>
                    <td><a href="route('user.edit,<?php echo e($item->id); ?>')" class="btn btn-sm btn-success">Edit</a></td>
                    <td><a href="/user.delete,<?php echo e($item->id); ?>" class="btn btn-sm btn-danger">Delete</a></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/user/index.blade.php ENDPATH**/ ?>